import SearchPanel from "./SearchPanel";

export default SearchPanel;
